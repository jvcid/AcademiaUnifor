package com.example.academiaunifor

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class CriarTreinoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_criar_treino)

        setupGrupoMuscular(R.id.btnPeito, R.id.layoutExPeito)
        setupGrupoMuscular(R.id.btnCostas, R.id.layoutExCostas)
        setupGrupoMuscular(R.id.btnBiceps, R.id.layoutExBiceps)
        setupGrupoMuscular(R.id.btnTriceps, R.id.layoutExTriceps)
        setupGrupoMuscular(R.id.btnPerna, R.id.layoutExPerna)
        setupGrupoMuscular(R.id.btnOmbros, R.id.layoutExOmbros)
    }

    private fun setupGrupoMuscular(btnId: Int, layoutId: Int) {
        val button = findViewById<Button>(btnId)
        val layout = findViewById<LinearLayout>(layoutId)

        button.setOnClickListener {
            layout.visibility = if (layout.visibility == View.GONE) View.VISIBLE else View.GONE
        }
    }
}
