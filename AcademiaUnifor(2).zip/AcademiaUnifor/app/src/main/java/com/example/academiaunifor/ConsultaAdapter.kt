package com.example.academiaunifor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ConsultaAdapter(
    private val onDesmarcarClick: (Consulta) -> Unit
) : ListAdapter<Consulta, ConsultaAdapter.ConsultaViewHolder>(ConsultaDiffCallback()) {

    inner class ConsultaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvProfessor: TextView = itemView.findViewById(R.id.tvProfessor)
        private val tvData: TextView = itemView.findViewById(R.id.tvData)
        private val tvHorario: TextView = itemView.findViewById(R.id.tvHorario)
        private val btnDesmarcar: Button = itemView.findViewById(R.id.btnDesmarcar)

        fun bind(consulta: Consulta) {
            tvProfessor.text = "Professor: ${consulta.professorNome}"
            tvData.text = "Data: ${consulta.data}"
            tvHorario.text = "Horário: ${consulta.horario}"
            btnDesmarcar.setOnClickListener { onDesmarcarClick(consulta) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConsultaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_consulta, parent, false)
        return ConsultaViewHolder(view)
    }

    override fun onBindViewHolder(holder: ConsultaViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}

class ConsultaDiffCallback : DiffUtil.ItemCallback<Consulta>() {
    override fun areItemsTheSame(oldItem: Consulta, newItem: Consulta) = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: Consulta, newItem: Consulta) = oldItem == newItem
}