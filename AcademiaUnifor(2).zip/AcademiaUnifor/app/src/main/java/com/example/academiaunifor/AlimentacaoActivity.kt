package com.example.academiaunifor

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager

class AlimentacaoActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlimentacaoAdapter
    private val listaAlimentos = mutableListOf<Alimento>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_alimentacao)

        recyclerView = findViewById(R.id.recyclerViewAlimentacao)
        adapter = AlimentacaoAdapter(listaAlimentos) { posicao ->
            confirmarRemocao(posicao)
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val btnAdicionar: Button = findViewById(R.id.btnAdicionarAlimento)
        btnAdicionar.setOnClickListener {
            mostrarDialogoAdicionar()
        }
    }

    private fun mostrarDialogoAdicionar() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 10)
        }

        val inputNome = EditText(this).apply {
            hint = "Nome do alimento"
        }
        val inputCalorias = EditText(this).apply {
            hint = "Calorias"
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        layout.addView(inputNome)
        layout.addView(inputCalorias)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Alimentação")
            .setView(layout)
            .setPositiveButton("Adicionar") { _, _ ->
                val nome = inputNome.text.toString()
                val calorias = inputCalorias.text.toString().toIntOrNull() ?: 0

                if (nome.isNotBlank()) {
                    val alimento = Alimento(nome, calorias)
                    listaAlimentos.add(alimento)
                    adapter.notifyItemInserted(listaAlimentos.size - 1)
                } else {
                    Toast.makeText(this, "Preencha o nome!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    private fun confirmarRemocao(posicao: Int) {
        AlertDialog.Builder(this)
            .setTitle("Remover item")
            .setMessage("Deseja remover este alimento da lista?")
            .setPositiveButton("Sim") { _, _ ->
                listaAlimentos.removeAt(posicao)
                adapter.notifyItemRemoved(posicao)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}


