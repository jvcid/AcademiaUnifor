package com.example.academiaunifor

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager

class AlimentacaoUsuarioActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlimentacaoUsuarioAdapter
    private val listaAlimentos = mutableListOf<Alimento>(
        Alimento("Frango Grelhado", 250),
        Alimento("Arroz Integral", 200)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_alimentacao_usuario)

        recyclerView = findViewById(R.id.recyclerViewAlimentacao)
        adapter = AlimentacaoUsuarioAdapter(listaAlimentos)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

    }
}


