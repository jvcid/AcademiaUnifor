package com.example.academiaunifor

    data class Maquina(
        var nome: String,
        val grupo: String
    )
