package com.example.academiaunifor

class Paciente(val nome: String?)