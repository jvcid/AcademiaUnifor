package com.example.academiaunifor

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ConsultaActivity : AppCompatActivity() {

    private lateinit var btnMarcarConsulta: Button
    private lateinit var btnVerConsultas: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta)

        btnMarcarConsulta = findViewById(R.id.btnMarcarConsulta)
        btnVerConsultas = findViewById(R.id.btnVerConsultas)

        btnMarcarConsulta.setOnClickListener {
            val intent = Intent(this, CalendarioActivity::class.java)
            startActivity(intent)
        }

        btnVerConsultas.setOnClickListener {
            // Aqui você pode implementar a lógica para ver as consultas
        }
    }
}
