package com.example.academiaunifor

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MeusTreinosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.meus_treinos)

        val btnProgressaoCarga = findViewById<Button>(R.id.btnProgressaoCarga)
        btnProgressaoCarga.setOnClickListener {
            val intent = Intent(this, ProgressaoCargaActivity::class.java)
            startActivity(intent)
        }

        val addButton = findViewById<Button>(R.id.btnAddTreino)
        addButton.setOnClickListener {
            showTreinoOptionsDialog()
        }

        val btnMaquinas = findViewById<Button>(R.id.btnMaquinas)
        btnMaquinas.setOnClickListener {
            val intent = Intent(this, EditarMaquinaActivity::class.java)
            startActivity(intent)
        }

    }

    private fun showTreinoOptionsDialog() {
        val options = arrayOf("Criar Treino", "Editar Treino")

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Escolha uma opção")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(this, CriarTreinoActivity::class.java)
                        startActivity(intent)
                    }
                    1 -> {
                        val intent = Intent(this, EditarTreinoActivity::class.java)
                        startActivity(intent)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)

        val dialog = builder.create()
        dialog.show()
    }
}
