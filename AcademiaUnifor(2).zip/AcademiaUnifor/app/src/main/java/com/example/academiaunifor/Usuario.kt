package com.example.academiaunifor

data class Usuario(
    val id: String = "",
    val nome: String = "",
    val role: String = ""  // "user" ou "admin"
) {
    val isProfessor: Boolean
        get() = role == "admin"
}
