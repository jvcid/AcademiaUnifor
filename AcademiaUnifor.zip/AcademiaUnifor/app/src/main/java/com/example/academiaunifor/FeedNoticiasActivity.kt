package com.example.academiaunifor

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.academiaunifor.databinding.ActivityFeedNoticiasBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class FeedNoticiasActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFeedNoticiasBinding
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private lateinit var newsAdapter: NewsAdapter
    private var newsListener: ListenerRegistration? = null
    private var isAdmin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedNoticiasBinding.inflate(layoutInflater)
        setContentView(binding.root)

        checkUserRole()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        newsAdapter = NewsAdapter(
            onItemClick = { openNewsDetail(it) },
            showDelete = isAdmin
        )
        binding.recyclerViewNews.apply {
            layoutManager = LinearLayoutManager(this@FeedNoticiasActivity)
            adapter = newsAdapter
        }
    }

    private fun startListeningForNews() {
        newsListener = db.collection("noticias")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                val newsList = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(News::class.java)?.copy(id = doc.id)
                } ?: emptyList()
                newsAdapter.submitList(newsList)
            }
    }

    private fun checkUserRole() {
        auth.currentUser?.uid?.let { uid ->
            db.collection("usuarios").document(uid).get()
                .addOnSuccessListener { document ->
                    val role = document.getString("role")
                    isAdmin = role == "admin"
                    binding.fabCriarNoticia.visibility = if (isAdmin) View.VISIBLE else View.GONE
                    setupRecyclerView()
                    startListeningForNews()
                }
        }
    }

    private fun setupClickListeners() {
        binding.fabCriarNoticia.setOnClickListener {
            startActivity(Intent(this, CriarNoticiaActivity::class.java))
        }
    }

    private fun openNewsDetail(news: News) {
        val intent = Intent(this, DetalheNoticiaActivity::class.java).apply {
            putExtra("titulo", news.titulo)
            putExtra("autor", news.autor)
            putExtra("texto", news.texto)
            putExtra("data", news.timestamp?.time ?: 0L)
        }
        startActivity(intent)
    }

    override fun onStop() {
        super.onStop()
        newsListener?.remove()
    }
}
