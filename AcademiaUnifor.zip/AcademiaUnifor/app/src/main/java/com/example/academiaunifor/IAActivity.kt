package com.example.academiaunifor

import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.*

class IAActivity : AppCompatActivity() {

    lateinit var textMensagem: EditText
    lateinit var btnEnviar: FloatingActionButton
    lateinit var textResposta: TextView
    val escopo = CoroutineScope(Dispatchers.Main + Job())


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_ia)

        textMensagem = findViewById(R.id.editTextTextMensagem)
        btnEnviar = findViewById(R.id.floatingActionButtonEnviar)
        textResposta = findViewById(R.id.textResposta)

    }

    override fun onStart() {
        super.onStart()
        btnEnviar.setOnClickListener {
            val userMessage = textMensagem.text.toString().trim()

            if (userMessage.isNotEmpty()) {
                textResposta.text = "Aguarde..."

                escopo.launch {
                    val resposta = GeminiHelper.responder(userMessage)
                    textResposta.text = resposta
                }
            }

        }

    }

    override fun onDestroy() {
        super.onDestroy()
        escopo.cancel()
    }

}
