package com.example.academiaunifor

import java.io.Serializable

data class Alimento (val nome: String, val calorias: Int) : Serializable
