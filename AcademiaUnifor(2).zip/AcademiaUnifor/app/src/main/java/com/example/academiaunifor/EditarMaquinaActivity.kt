package com.example.academiaunifor

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.academiaunifor.databinding.ActivityEditarMaquinaBinding
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class EditarMaquinaActivity : AppCompatActivity() {

    private lateinit var searchBar: EditText
    private lateinit var container: LinearLayout
    private lateinit var fabAdicionar: ExtendedFloatingActionButton
    private val allMaquinas = mutableListOf<Maquina>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_maquina)

        searchBar = findViewById(R.id.searchBar)
        container = findViewById(R.id.scrollViewContent)

        // Inicializa o ExtendedFloatingActionButton
        fabAdicionar = findViewById(R.id.fabAdicionar)

        preencherMaquinas()
        mostrarMaquinas(allMaquinas)

        searchBar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val texto = s.toString().lowercase()
                val filtradas = allMaquinas.filter { it.nome.lowercase().contains(texto) }
                mostrarMaquinas(filtradas)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        fabAdicionar.setOnClickListener {
            exibirDialogAdicionar()
        }
    }

    private fun preencherMaquinas() {
        allMaquinas.apply {
            add(Maquina("Supino Reto", "Peitoral"))
            add(Maquina("Supino Inclinado", "Peitoral"))
            add(Maquina("Crossover na Polia", "Peitoral"))
            add(Maquina("Puxada Alta", "Costas"))
            add(Maquina("Remada Curvada", "Costas"))
            add(Maquina("Remada Unilateral", "Costas"))
            add(Maquina("Desenvolvimento com Halteres", "Ombros"))
            add(Maquina("Elevação Lateral", "Ombros"))
            add(Maquina("Elevação Frontal", "Ombros"))
            add(Maquina("Rosca Direta", "Bíceps"))
            add(Maquina("Rosca Martelo", "Bíceps"))
            add(Maquina("Rosca Scott", "Bíceps"))
            add(Maquina("Tríceps Testa", "Tríceps"))
            add(Maquina("Tríceps Corda", "Tríceps"))
            add(Maquina("Tríceps Francês", "Tríceps"))
            add(Maquina("Agachamento Livre", "Pernas"))
            add(Maquina("Leg Press", "Pernas"))
            add(Maquina("Extensora", "Pernas"))
            add(Maquina("Elevação na Leg Press", "Panturrilha"))
            add(Maquina("Elevação Sentado", "Panturrilha"))
            add(Maquina("Abdominal Infra", "Abdômen"))
            add(Maquina("Abdominal Oblíquo", "Abdômen"))
            add(Maquina("Abdominal na Máquina", "Abdômen"))
        }
    }

    private fun mostrarMaquinas(lista: List<Maquina>) {
        container.removeAllViews()

        val agrupado = lista.groupBy { it.grupo }

        for ((grupo, maquinasDoGrupo) in agrupado) {
            val titulo = TextView(this).apply {
                text = grupo
                setTextAppearance(android.R.style.TextAppearance_Medium)
                setTextColor(resources.getColor(android.R.color.white))
                setPadding(0, 24, 0, 8)
            }
            container.addView(titulo)

            for (maquina in maquinasDoGrupo) {
                val item = TextView(this).apply {
                    text = maquina.nome
                    setTextColor(resources.getColor(android.R.color.white))
                    textSize = 16f
                    setPadding(0, 8, 0, 8)
                    setOnClickListener {
                        exibirDialogEditar(maquina)
                    }
                }
                container.addView(item)
            }
        }
    }

    private fun exibirDialogEditar(maquina: Maquina) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_editar_maquina, null)
        val nomeEditText = dialogView.findViewById<EditText>(R.id.etNomeMaquina)

        nomeEditText.setText(maquina.nome)

        AlertDialog.Builder(this)
            .setTitle("Editar Máquina")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                maquina.nome = nomeEditText.text.toString()
                mostrarMaquinas(allMaquinas.filter {
                    it.nome.contains(searchBar.text.toString(), ignoreCase = true)
                })
            }
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Excluir") { _, _ ->
                allMaquinas.remove(maquina)
                mostrarMaquinas(allMaquinas.filter {
                    it.nome.contains(searchBar.text.toString(), ignoreCase = true)
                })
            }
            .show()
    }

    private fun exibirDialogAdicionar() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_editar_maquina, null)
        val nomeEditText = dialogView.findViewById<EditText>(R.id.etNomeMaquina)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Máquina")
            .setView(dialogView)
            .setPositiveButton("Adicionar") { _, _ ->
                val nome = nomeEditText.text.toString()
                if (nome.isNotBlank()) {
                    // Aqui você pode perguntar o grupo também, ou deixar como "Outro"
                    allMaquinas.add(Maquina(nome, "Outro"))
                    mostrarMaquinas(allMaquinas.filter {
                        it.nome.contains(searchBar.text.toString(), ignoreCase = true)
                    })
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
