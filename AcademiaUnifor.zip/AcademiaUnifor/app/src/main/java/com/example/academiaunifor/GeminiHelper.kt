package com.example.academiaunifor

object GeminiHelper {

    fun responder(pergunta: String): String {
        // Resposta fixa ou lógica simples, sem IA
        return "Ainda não implementado."
    }
}
