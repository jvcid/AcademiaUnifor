package com.example.academiaunifor

import android.graphics.Color
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PacienteAdapter(
    private val pacientes: List<Paciente>,
    private val onClick: (Paciente) -> Unit
) : RecyclerView.Adapter<PacienteAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val foto: ImageView = itemView.findViewById(R.id.fotoPaciente)
        private val nome: TextView = itemView.findViewById(R.id.nomePaciente)

        fun bind(paciente: Paciente, onClick: (Paciente) -> Unit) {
            nome.text = paciente.nome

            // Criar círculo cinza programaticamente para fotoPaciente
            val circleDrawable = ShapeDrawable(OvalShape()).apply {
                intrinsicHeight = 100  // ajuste o tamanho se quiser
                intrinsicWidth = 100
                paint.color = Color.GRAY  // cor do círculo
            }
            foto.setImageDrawable(circleDrawable)

            itemView.setOnClickListener { onClick(paciente) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_paciente, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(pacientes[position], onClick)
    }

    override fun getItemCount(): Int = pacientes.size
}
