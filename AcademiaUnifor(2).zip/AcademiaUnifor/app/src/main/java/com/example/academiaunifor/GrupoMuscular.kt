package com.example.academiaunifor

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class GrupoMuscular(
    var nome: String,
    var exercicios: MutableList<String>
) : Parcelable