package com.example.academiaunifor

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class InicioActivity : AppCompatActivity() {

    lateinit var welcomeText: TextView
    lateinit var btnIa: Button
    lateinit var btnAlimentacao: Button
    lateinit var btnConsulta: Button
    lateinit var btnColegas: Button
    lateinit var btnNoticias: Button
    lateinit var btnTreinos: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio)

        welcomeText = findViewById(R.id.textViewInicio)
        btnIa = findViewById(R.id.buttonIa)
        btnAlimentacao = findViewById(R.id.buttonAlimentacao)
        btnConsulta = findViewById(R.id.buttonConsulta)
        btnColegas = findViewById(R.id.buttonColegas)
        btnNoticias = findViewById(R.id.buttonNoticias)
        btnTreinos = findViewById(R.id.buttonTreinos)

        // Ajuste automático para barra de status
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnTreinos.setOnClickListener {
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            if (uid != null) {
                FirebaseFirestore.getInstance().collection("usuarios").document(uid).get()
                    .addOnSuccessListener { document ->
                        val role = document.getString("role")
                        when (role) {
                            "admin" -> startActivity(Intent(this, MeusTreinosActivity::class.java))
                            "user" -> startActivity(Intent(this, MeusTreinosUsuarioActivity::class.java))
                            else -> Toast.makeText(this, "Tipo de usuário inválido: $role", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Erro ao verificar tipo de usuário", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            }
        }

        btnAlimentacao.setOnClickListener {
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            if (uid != null) {
                FirebaseFirestore.getInstance().collection("usuarios").document(uid).get()
                    .addOnSuccessListener { document ->
                        val role = document.getString("role")
                        when (role) {
                            "admin" -> startActivity(Intent(this, AlimentacaoActivity::class.java))
                            "user" -> startActivity(Intent(this, AlimentacaoUsuarioActivity::class.java))
                            else -> Toast.makeText(this, "Tipo de usuário inválido: $role", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Erro ao verificar tipo de usuário", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            }
        }

        btnIa.setOnClickListener {
            val intent = Intent(this, IAActivity::class.java)
            startActivity(intent)
        }

        btnColegas.setOnClickListener {
            val intent = Intent(this, ColegasActivity::class.java)
            startActivity(intent)
        }

        btnConsulta.setOnClickListener {
            val intent = Intent(this, ConsultaActivity::class.java)
            startActivity(intent)
        }

        btnNoticias.setOnClickListener {
            val intent = Intent(this, FeedNoticiasActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        val username = intent.getStringExtra("username")
        welcomeText.text = "Bem-vindo, $username!"
    }
}
