package com.example.academiaunifor

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MeusTreinosUsuarioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.meus_treinos_usuario)

        val btnProgressaoCarga = findViewById<Button>(R.id.btnProgressaoCarga)
        btnProgressaoCarga.setOnClickListener {
            val intent = Intent(this, ProgressaoCargaActivity::class.java)
            startActivity(intent)
        }

    }

}
