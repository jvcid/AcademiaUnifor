package com.example.academiaunifor

data class Consulta(
    var id: String = "",
    val alunoId: String = "",
    val alunoNome: String = "",
    val professorId: String = "",
    val professorNome: String = "",
    val data: String = "",
    val horario: String = "",
    val status: String = "Agendada" // Pode ser: Agendada, Cancelada, Realizada
)