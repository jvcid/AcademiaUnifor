package com.example.academiaunifor

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class VerConsultasActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ConsultaAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_consultas)

        recyclerView = findViewById(R.id.recyclerConsultas)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ConsultaAdapter { consulta -> showDesmarcarDialog(consulta) }
        recyclerView.adapter = adapter

        carregarConsultas()
    }

    private fun carregarConsultas() {
        val userId = auth.currentUser?.uid ?: return run {
            Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            finish()
        }

        db.collection("consultas")
            .whereEqualTo("alunoId", userId)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Toast.makeText(this, "Erro ao carregar consultas", Toast.LENGTH_SHORT).show()
                    Log.e("VerConsultas", "Erro: ${error.message}")
                    return@addSnapshotListener
                }

                val consultas = snapshots?.documents?.mapNotNull { doc ->
                    doc.toObject(Consulta::class.java)?.apply {
                        id = doc.id
                        Log.d("ConsultaData", "Doc: ${doc.data}")
                    }
                } ?: emptyList()

                if (consultas.isEmpty()) {
                    Toast.makeText(this, "Nenhuma consulta marcada", Toast.LENGTH_SHORT).show()
                } else {
                    consultas.forEach {
                        Log.d("ConsultaData", "Consulta: ${it.professorNome} - ${it.data} ${it.horario}")
                    }
                }

                adapter.submitList(consultas)
            }
    }

    private fun showDesmarcarDialog(consulta: Consulta) {
        AlertDialog.Builder(this)
            .setTitle("Desmarcar Consulta")
            .setMessage("Tem certeza que deseja desmarcar a consulta com ${consulta.professorNome} no dia ${consulta.data} às ${consulta.horario}?")
            .setPositiveButton("Desmarcar") { _, _ ->
                desmarcarConsulta(consulta.id)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun desmarcarConsulta(consultaId: String) {
        db.collection("consultas").document(consultaId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Consulta desmarcada com sucesso", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao desmarcar: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}