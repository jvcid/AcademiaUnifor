package com.example.academiaunifor

import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CalendarioActivity : AppCompatActivity() {

    private lateinit var calendarView: CalendarView
    private lateinit var btnConfirmar: Button
    private lateinit var tvHorarios: TextView
    private var dataSelecionada: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendario)

        calendarView = findViewById(R.id.calendarView)
        btnConfirmar = findViewById(R.id.btnConfirmarConsulta)
        tvHorarios = findViewById(R.id.tvHorarios)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            dataSelecionada = "$dayOfMonth/${month + 1}/$year"
            Toast.makeText(this, "Data selecionada: $dataSelecionada", Toast.LENGTH_SHORT).show()
        }

        btnConfirmar.setOnClickListener {
            if (dataSelecionada.isNotEmpty()) {
                Toast.makeText(this, "Consulta marcada para $dataSelecionada", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Selecione uma data antes de confirmar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
