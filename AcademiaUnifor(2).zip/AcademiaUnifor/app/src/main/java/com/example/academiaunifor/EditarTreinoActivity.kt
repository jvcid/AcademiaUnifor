package com.example.academiaunifor

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.academiaunifor.databinding.ActivityEditarTreinoBinding

class EditarTreinoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditarTreinoBinding
    private var grupo: GrupoMuscular? = null
    private var posGrupo: Int = -1
    private var posExercicio: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditarTreinoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recuperando os dados passados pela Intent
        grupo = intent.getSerializableExtra("grupo") as? GrupoMuscular
        posGrupo = intent.getIntExtra("posGrupo", -1)
        posExercicio = intent.getIntExtra("posExercicio", -1)

        // Verificando se os dados são válidos
        if (grupo != null && posExercicio >= 0) {
            binding.editNomeExercicio.setText(grupo!!.exercicios[posExercicio])
        }

        binding.btnSalvar.setOnClickListener {
            val novoNome = binding.editNomeExercicio.text.toString()
            if (novoNome.isNotBlank()) {
                // Atualizando o nome do exercício
                grupo?.exercicios?.set(posExercicio, novoNome)

                // Retornando o resultado atualizado
                val resultIntent = intent.apply {
                    putExtra("grupo", grupo)
                    putExtra("posGrupo", posGrupo)
                    putExtra("posExercicio", posExercicio)
                }


                setResult(RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Nome inválido", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
