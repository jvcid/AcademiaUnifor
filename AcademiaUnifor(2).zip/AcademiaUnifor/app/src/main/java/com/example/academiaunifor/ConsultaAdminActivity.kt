package com.example.academiaunifor

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ConsultaAdminActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PacienteAdapter
    private val pacientes = ArrayList<Paciente>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_admin)

        recyclerView = findViewById(R.id.recyclerViewPacientes)

        pacientes.add(Paciente("Ana Souza"))
        pacientes.add(Paciente("João Lima"))
        pacientes.add(Paciente("Carlos Silva"))
        pacientes.add(Paciente("Maria Luz"))

        adapter = PacienteAdapter(pacientes) { paciente ->
            // Agora apenas exibe uma mensagem ou executa outro comportamento
            Toast.makeText(this, "Clicou em ${paciente.nome}", Toast.LENGTH_SHORT).show()
        }

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.adapter = adapter
    }
}
